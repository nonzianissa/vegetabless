package com.vegetables;

import java.util.ArrayList;

public class SayurData {
    private static String[] sayurNames = {
            "Brokoli",
            "KUBIS",
            "WORTEL",
            "TERONG",
            "BAWANG MERAH",
            "CABAI",
            "KENTANG",
            "PAPRIKA",
            "BAYAM",
            "JAGUNG"
    };

    private static String[] sayurDetails = {
            "Brokoli (Brassica oleracea L. Kelompok Italica) adalah tanaman sayuran yang termasuk dalam suku kubis-kubisan atau Brassicaceae. Brokoli berasal dari daerah Laut Tengah dan sudah sejak masa Yunani Kuno dibudidayakan. ",
            "Kubis, kol, kobis, atau kobis bulat (terdiri dari beberapa kelompok kultivar dari Brassica oleracea) adalah tanaman dua tahunan hijau atau ungu berdaun, ditanam sebagai tanaman tahunan sayuran untuk kepala padat berdaunnya. ",
            "Wortel adalah tumbuhan biennial (siklus hidup 12 - 24 bulan) yang menyimpan karbohidrat dalam jumlah besar untuk tumbuhan tersebut berbunga pada tahun kedua. ",
            "Terung atau terong[1] (Solanum melongena) adalah tumbuhan penghasil buah yang dijadikan sayur-sayuran. Asalnya adalah India dan Sri Lanka[2][3]. Terung berkerabat dekat dengan kentang dan leunca, dan agak jauh dari tomat.",
            "Bawang merupakan istilah umum bagi sekelompok tumbuhan penting bagi manusia yang termasuk dalam genus Allium. Umbi, daun, atau bunga bawang dimanfaatkan sebagai sayuran atau sebagai rempah-rempah, tergantung bagaimana kita memandangnya.",
            "Cabai atau cabai merah adalah buah dan tumbuhan anggota genus Capsicum. Buahnya dapat digolongkan sebagai sayuran maupun bumbu, tergantung bagaimana digunakan.",
            "Kentang (Solanum tuberosum L.) adalah tanaman dari suku Solanaceae yang memiliki umbi batang yang dapat dimakan dan disebut \"kentang\" pula. Umbi kentang sekarang telah menjadi salah satu makanan pokok penting di Eropa walaupun pada awalnya didatangkan dari Amerika Selatan.",
            "Paprika (Capsicum annuum L.) adalah tumbuhan penghasil buah yang berasa manis dan sedikit pedas dari suku terong-terongan atau Solanaceae). Buahnya yang berwarna hijau, kuning, merah, atau ungu sering digunakan sebagai campuran salad. ",
            "Bayam adalah tanaman sayur-sayuran dengan nama ilmiah Amaranthus spp. Kata \"amaranth\" dalam bahasa Yunani berarti \"everlasting\" (abadi). Tumbuhan ini dikenal sebagai sayuran sumber zat besi yang penting. ",
            "Jagung (Zea mays ssp. mays) adalah salah satu tanaman pangan penghasil karbohidrat yang terpenting di dunia, selain gandum dan padi. Bagi penduduk Amerika Tengah dan Selatan, bulir jagung adalah pangan pokok, sebagaimana bagi sebagian penduduk Afrika dan beberapa daerah di Indonesia. "
    };

    private static int[] sayurImages = {
            R.drawable.brokoli,
            R.drawable.kubis,
            R.drawable.wortel,
            R.drawable.terong,
            R.drawable.bawang,
            R.drawable.cabai,
            R.drawable.kentang,
            R.drawable.paprika,
            R.drawable.bayam,
            R.drawable.jagung

    };

    static ArrayList<Sayur> getListData() {
        ArrayList<Sayur> list = new ArrayList<>();
        for (int position = 0; position < sayurNames.length; position++) {
            Sayur sayur = new Sayur();
            sayur.setName(sayurNames[position]);
            sayur.setDetail(sayurDetails[position]);
            sayur.setPhoto(sayurImages[position]);
            list.add(sayur);
        }
        return list;
    }


};
