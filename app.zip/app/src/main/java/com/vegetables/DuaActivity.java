package com.vegetables;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DuaActivity extends AppCompatActivity {
    private RecyclerView rvSayur;
    private ArrayList<Sayur> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dua);

        rvSayur = findViewById(R.id.rv_sayur);
        rvSayur.setHasFixedSize(true);

        list.addAll(SayurData.getListData());
        showRecyclerList();
    }


    private void showRecyclerList() {
        rvSayur.setLayoutManager(new LinearLayoutManager(this));
        ListSayurAdapter listHeroAdapter = new ListSayurAdapter(list);
        rvSayur.setAdapter(listHeroAdapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }
    public void setMode(int selectedMode) {
        switch (selectedMode) {
            case R.id.action_list:
                break;
            case R.id.action_grid:
                break;
            case R.id.action_cardview:
                break;
        }
    }

}

