package com.vegetables;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private RecyclerView rvSayur;
    private ArrayList<Sayur> list = new ArrayList<>();
    private String title = "Mode List";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dua);
        setActionBarTitle(title);


        rvSayur = findViewById(R.id.rv_sayur);
        rvSayur.setHasFixedSize(true);

        list.addAll(SayurData.getListData());
        showRecyclerList();
    }


    private void showRecyclerList() {
        rvSayur.setLayoutManager(new LinearLayoutManager(this));
        ListSayurAdapter listSayurAdapter = new ListSayurAdapter(list);
        rvSayur.setAdapter(listSayurAdapter);
    }

    private void showRecyclerGrid() {
        rvSayur.setLayoutManager(new GridLayoutManager(this, 2));
        GridSayurAdapter gridSayurAdapter = new GridSayurAdapter(list);
        rvSayur.setAdapter(gridSayurAdapter);
    }
    private void showRecyclerCardView(){
        rvSayur.setLayoutManager(new LinearLayoutManager(this));
        CardViewSayurAdapter cardViewHeroAdapter = new CardViewSayurAdapter(list);
        rvSayur.setAdapter(cardViewHeroAdapter);
    }

    private void setActionBarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        setMode(item.getItemId());
        return super.onOptionsItemSelected(item);
    }




    public void setMode(int selectedMode) {
        switch (selectedMode) {
            case R.id.action_list:
                title = "List Vegetabel";
                showRecyclerList();
                break;
            case R.id.action_grid:
                title = "Grid Vegetable";
                showRecyclerGrid();
                break;
            case R.id.action_cardview:
                title = "CardView Vegetable";
                showRecyclerCardView();
                break;
        }

        setActionBarTitle(title);

    }

    }







